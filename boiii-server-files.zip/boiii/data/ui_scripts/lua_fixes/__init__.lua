
-- Fix LUI_NULL_FUNCTION messages
function Engine.PIXBeginEvent() end
function Engine.PIXEndEvent() end